import "./site.styl";

let canvas = document.getElementById("canvas") as HTMLCanvasElement;
let context = canvas.getContext("2d");

window.addEventListener("resize", resizeCanvas, false);

function resizeCanvas(): void {
	let c1 = document.getElementById("canvas") as HTMLCanvasElement;
	let c2 = canvas.getContext("2d");

	canvas.width = window.innerWidth;
	canvas.height = window.innerHeight;
	drawStuff(canvas.width, canvas.height);
}

resizeCanvas();

function drawStuff(width: number, height: number): void {
	context.beginPath();
	context.moveTo(0, 0);
	context.lineTo(width, height);
	context.strokeStyle = "#ff0000";
	context.stroke();
	context.closePath();
}

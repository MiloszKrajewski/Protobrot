﻿export function hello(): void {
	console.log("Hello from other");
}
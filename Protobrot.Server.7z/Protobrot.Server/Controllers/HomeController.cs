﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Server.Kestrel.Internal.Networking;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using SkiaSharp;

namespace Protobrot.Server.Controllers
{
	public class HomeController: Controller
	{
		public ILogger<HomeController> Log { get; }

		public HomeController(ILoggerFactory loggers)
		{
			Log = loggers?.CreateLogger<HomeController>();
		}

		public IActionResult Index() => View();
			// new RedirectResult("/home/plan?w=1400&h=800&sx=-2.5&sy=-1&ex=1&ey=1");

		public IActionResult Plan(int w, int h, double sx, double sy, double ex, double ey)
		{
			var screen = Extent.Create(0, 0, w - 1, h - 1);
			var extent = Extent.Create(sx, sy, ex, ey).Aspect(screen.Aspect());

			double tx(int x) => MathEx.Translate(x, 0, w - 1, extent.S.X, extent.E.X);
			double ty(int y) => MathEx.Translate(y, 0, h - 1, extent.S.Y, extent.E.Y);

			var i = (int) Math.Sqrt(screen.Area() / extent.Area()) / 4;

			var boxes = Partition(screen, 0xFFFF, 0xFFFF)
				.Select(e => $"i={i}&w={e.Width()}&h={e.Height()}&sx={tx(e.S.X)}&sy={ty(e.S.Y)}&ex={tx(e.E.X)}&ey={ty(e.E.Y)}")
				.Select(q => $"/home/image?{q}");

			return new JsonResult(boxes);
		}

		public IActionResult Image(int i, int w, int h, double sx, double sy, double ex, double ey)
		{
			using (var bitmap = Paint(i, w, h, Extent.Create(sx, sy, ex, ey)))
				return new FileStreamResult(Save(bitmap), "image/png");
		}

		private static IEnumerable<Extent<int>> Partition(Extent<int> screen, int width, int height)
		{
			var ey = screen.E.Y;
			var ex = screen.E.X;

			var sy = screen.S.Y;
			while (sy < ey)
			{
				var sx = screen.S.X;
				while (sx < ex)
				{
					yield return Extent.Create(
						sx,
						sy,
						Math.Min(sx + width - 1, ex),
						Math.Min(sy + height - 1, ey));

					sx += width;
				}

				sy += height;
			}
		}

		private SKBitmap Paint(int i, int w, int h, Extent<double> extent)
		{
			var bitmap = new SKBitmap(w, h, SKColorType.Bgra8888, SKAlphaType.Opaque);
			var start = Stopwatch.StartNew();
			Paintbrot.Paint(bitmap, Extent.Create(0, 0, w, h), extent, i, Palette);
			Log.LogDebug($"Madelbrot(Size:{w}x{h}x{i}, Elapsed:{start.Elapsed.TotalMilliseconds:F}ms)");
			return bitmap;
		}

		public Stream Save(SKBitmap bitmap)
		{
			var file = (Stream) new MemoryStream();

			using (var image = SKImage.FromBitmap(bitmap))
			using (var data = image.Encode(SKEncodedImageFormat.Png, 80))
			{
				data.SaveTo(file);
			}

			file.Position = 0;

			return file;
		}

		private static SKColor Rgb(int r, int g, int b) => new SKColor((byte) r, (byte) g, (byte) b);

		private static readonly SKColor[] Palette = {
			Rgb(66, 30, 15),
			Rgb(25, 7, 26),
			Rgb(9, 1, 47),
			Rgb(4, 4, 73),
			Rgb(0, 7, 100),
			Rgb(12, 44, 138),
			Rgb(24, 82, 177),
			Rgb(57, 125, 209),
			Rgb(134, 181, 229),
			Rgb(211, 236, 248),
			Rgb(241, 233, 191),
			Rgb(248, 201, 95),
			Rgb(255, 170, 0),
			Rgb(204, 128, 0),
			Rgb(153, 87, 0),
			Rgb(106, 52, 3)
		};
	}
}

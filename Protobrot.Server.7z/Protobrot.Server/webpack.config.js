var path = require('path');

module.exports = {
	entry: {
		main: './Scripts/index.ts'
	},
	output: {
		path: path.join(__dirname, '/wwwroot/js/'),
		filename: 'index.js'
	},
	resolve: {
		extensions: [".ts", ".tsx", ".js"]
	},
	module: {
		loaders: [
			{ test: /\.tsx?$/, exclude: /node_modules/, loader: "ts-loader" },
			{ test: /\.styl$/, exclude: /node_modules/, loader: 'style-loader!css-loader!stylus-loader' }
		]
	}
};

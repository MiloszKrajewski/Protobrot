﻿using System;

namespace Protobrot.Server
{
	public static class Point
	{
		public static Point<T> Zero<T>() => new Point<T>();
		public static Point<T> Create<T>(T x, T y) => new Point<T>(x, y);

		public static Point<U> Map<T, U>(this Point<T> point, Func<T, U> map) => 
			new Point<U>(map(point.X), map(point.Y));
	}

	public struct Point<T>
	{
		public static readonly Point<T> Zero = new Point<T>();

		public T X { get; }
		public T Y { get; }

		public Point(T x, T y)
		{
			X = x;
			Y = y;
		}

		public override string ToString() => $"{GetType().Name}(X:{X}, Y:{Y})";
	}
}
